module.exports = {
	'&amp;': '<span class="token entity" title="&amp;">&amp;amp;</span>',
	'&thetasym;': '<span class="token entity" title="&thetasym;">&amp;thetasym;</span>'
};